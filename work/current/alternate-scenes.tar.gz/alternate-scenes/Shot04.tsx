import React from 'react';
import {interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {SceneStage} from '../../shared/SceneStage';
import {BentoBadge, BentoCard} from './SceneBento';

export const Shot04: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();

  const enterProgress = spring({frame, fps, config: {damping: 14, stiffness: 100}});
  const scale = interpolate(enterProgress, [0, 1], [0.94, 1]);

  // Clamp outline closure at frame 138
  const clampProgress = spring({
    frame: frame - 138,
    fps,
    config: {damping: 12, stiffness: 120},
  });

  return (
    <SceneStage>
      <div
        className="w-full h-full flex flex-col justify-between py-6 px-4"
        style={{transform: `scale(${scale})`}}
      >
        {/* Top Hero: Internet Pretraining Bias */}
        <BentoCard className="flex-1 mb-6 flex flex-col justify-between">
          <div className="flex justify-between items-center mb-4">
            <BentoBadge label="Corpus Architecture" color="#38BDF8" />
            <span className="text-lg font-mono text-slate-400">Pre-training Data</span>
          </div>

          <div className="flex-1 flex flex-col justify-center items-center text-center">
            <div className="text-xl font-mono text-slate-400 uppercase tracking-widest mb-3">
              Global Internet Corpus
            </div>
            <div className="text-7xl font-mono font-black text-white tracking-tight mb-4">
              90% ENGLISH
            </div>
            <p className="text-2xl text-slate-300 max-w-xl font-medium">
              Because LLMs trained primarily on English web text, English words received dedicated single-token IDs.
            </p>
          </div>

          <div className="flex justify-between items-center pt-4 border-t border-slate-700/50 text-slate-400 font-mono text-base">
            <span>Vocabulary Size: ~100k - 200k</span>
            <span className="text-cyan-400 font-bold">High Density Match</span>
          </div>
        </BentoCard>

        {/* Lower Card: Single Unified English Token Benchmark */}
        <BentoCard className="flex-1 flex flex-col justify-between">
          <div className="flex justify-between items-center mb-4">
            <BentoBadge label="English Benchmark" color="#10B981" bg="rgba(16, 185, 129, 0.15)" />
            <span className="text-lg font-mono text-emerald-400 font-semibold">1 Word = 1 Token</span>
          </div>

          <div className="flex-1 flex flex-col justify-center items-center">
            {/* Unified Green Token Block */}
            <div
              className="p-8 rounded-3xl bg-emerald-950/40 border-2 border-emerald-400 flex flex-col items-center justify-center shadow-xl shadow-emerald-500/20"
              style={{
                transform: `scale(${interpolate(clampProgress, [0, 1], [0.95, 1.05])})`,
              }}
            >
              <span className="text-sm font-mono text-emerald-300 uppercase tracking-wider mb-2">
                Unified Token Unit
              </span>
              <span className="text-5xl font-mono font-black text-white mb-2">"Technology"</span>
              <span className="text-2xl font-mono font-bold text-emerald-400 bg-emerald-900/60 px-5 py-1.5 rounded-full border border-emerald-500/40">
                1 Token [ID #9182]
              </span>
            </div>

            <div className="mt-6 text-slate-300 text-xl font-medium text-center">
              Retained as baseline reference for Bangla comparison
            </div>
          </div>
        </BentoCard>
      </div>
    </SceneStage>
  );
};
