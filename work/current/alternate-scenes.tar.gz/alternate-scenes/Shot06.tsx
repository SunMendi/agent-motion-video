import React from 'react';
import {interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {SceneStage} from '../../shared/SceneStage';
import {BentoBadge, BentoCard} from './SceneBento';

export const Shot06: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();

  const enterProgress = spring({frame, fps, config: {damping: 14, stiffness: 100}});
  const scale = interpolate(enterProgress, [0, 1], [0.94, 1]);

  // Pull apart marks at frame 154
  const pullProgress = spring({
    frame: frame - 154,
    fps,
    config: {damping: 12, stiffness: 100},
  });

  const gap = interpolate(pullProgress, [0, 1], [16, 48]);

  return (
    <SceneStage>
      <div
        className="w-full h-full flex flex-col justify-between py-6 px-4"
        style={{transform: `scale(${scale})`}}
      >
        {/* Top Hero: Anatomy of Combining Marks */}
        <BentoCard className="flex-1 mb-6 flex flex-col justify-between">
          <div className="flex justify-between items-center mb-4">
            <BentoBadge label="Script Complexity" color="#38BDF8" />
            <span className="text-lg font-mono text-slate-400">Unicode Deconstruction</span>
          </div>

          <div className="flex-1 flex flex-col justify-center items-center">
            <div className="text-slate-400 font-mono text-sm tracking-widest uppercase mb-4">
              Bangla Conjunct Deconstruction
            </div>

            {/* Separated Glyph Elements */}
            <div className="flex items-center justify-center my-4" style={{gap: `${gap}px`}}>
              <div className="flex flex-col items-center">
                <div className="text-6xl font-bold font-sans text-cyan-300 p-4 rounded-2xl bg-cyan-950/40 border border-cyan-500/40">
                  ক
                </div>
                <span className="text-xs font-mono text-slate-400 mt-2">Consonant</span>
              </div>

              <div className="text-3xl font-mono text-slate-500 font-bold">+</div>

              <div className="flex flex-col items-center">
                <div className="text-6xl font-bold font-sans text-amber-300 p-4 rounded-2xl bg-amber-950/40 border border-amber-500/40">
                  ্
                </div>
                <span className="text-xs font-mono text-slate-400 mt-2">Virama (হসন্ত)</span>
              </div>

              <div className="text-3xl font-mono text-slate-500 font-bold">+</div>

              <div className="flex flex-col items-center">
                <div className="text-6xl font-bold font-sans text-red-300 p-4 rounded-2xl bg-red-950/40 border border-red-500/40">
                  ষ
                </div>
                <span className="text-xs font-mono text-slate-400 mt-2">Consonant</span>
              </div>

              <div className="text-3xl font-mono text-slate-500 font-bold">+</div>

              <div className="flex flex-col items-center">
                <div className="text-6xl font-bold font-sans text-purple-300 p-4 rounded-2xl bg-purple-950/40 border border-purple-500/40">
                  ী
                </div>
                <span className="text-xs font-mono text-slate-400 mt-2">Kar-Sign (কার)</span>
              </div>
            </div>

            <div className="text-2xl text-slate-200 font-medium text-center mt-4">
              Each combining mark adds independent byte sequences
            </div>
          </div>
        </BentoCard>

        {/* Lower Card: Model-Dependent Splitting Warning */}
        <BentoCard className="flex-1 flex flex-col justify-between">
          <div className="flex justify-between items-center mb-4">
            <BentoBadge label="Model Variation" color="#F59E0B" bg="rgba(245, 158, 11, 0.15)" />
            <span className="text-lg font-mono text-slate-400">Token Efficiency</span>
          </div>

          <div className="grid grid-cols-3 gap-4 flex-1 items-center text-center">
            <div className="rounded-2xl p-4 bg-slate-900/60 border border-slate-700">
              <div className="text-sm font-mono text-slate-400 mb-1">GPT-3.5 Legacy</div>
              <div className="text-4xl font-mono font-bold text-red-400">5 TOKENS</div>
              <div className="text-xs font-mono text-slate-500 mt-1">High Byte Split</div>
            </div>

            <div className="rounded-2xl p-4 bg-slate-900/60 border border-slate-700">
              <div className="text-sm font-mono text-slate-400 mb-1">GPT-4o Modern</div>
              <div className="text-4xl font-mono font-bold text-amber-400">3 TOKENS</div>
              <div className="text-xs font-mono text-slate-500 mt-1">Expanded Vocab</div>
            </div>

            <div className="rounded-2xl p-4 bg-slate-900/60 border border-slate-700">
              <div className="text-sm font-mono text-slate-400 mb-1">Claude 3.5</div>
              <div className="text-4xl font-mono font-bold text-cyan-400">2-3 TOKENS</div>
              <div className="text-xs font-mono text-slate-500 mt-1">Multilingual BPE</div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-700/50 text-center text-sm font-mono text-slate-400">
            Note: Token counts depend on tokenizer architecture. Always test with your specific model.
          </div>
        </BentoCard>
      </div>
    </SceneStage>
  );
};
