import React from 'react';
import {interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {SceneStage} from '../../shared/SceneStage';
import {BentoBadge, BentoCard} from './SceneBento';

export const Shot03: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();

  const enterProgress = spring({frame, fps, config: {damping: 14, stiffness: 100}});
  const scale = interpolate(enterProgress, [0, 1], [0.94, 1]);

  // Scan line progress
  const scanX = interpolate(frame, [0, 90], [10, 90], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  // e03-resolve at frame 110
  const lockProgress = spring({
    frame: frame - 110,
    fps,
    config: {damping: 12, stiffness: 120},
  });

  return (
    <SceneStage>
      <div
        className="w-full h-full flex flex-col justify-between py-6 px-4"
        style={{transform: `scale(${scale})`}}
      >
        {/* Top Hero: Text to Numbers Converter Chamber */}
        <BentoCard className="flex-1 mb-6 flex flex-col justify-between">
          <div className="flex justify-between items-center mb-4">
            <BentoBadge label="Neural Input Layer" color="#38BDF8" />
            <span className="text-lg font-mono text-slate-400">Word → Vector ID</span>
          </div>

          <div className="relative flex-1 flex flex-col justify-center items-center my-4 p-8 rounded-2xl bg-slate-950/70 border border-slate-700/50 overflow-hidden">
            {/* Scan Beam */}
            <div
              className="absolute top-0 bottom-0 w-1 bg-cyan-400"
              style={{
                left: `${scanX}%`,
                boxShadow: '0 0 20px 4px rgba(56, 189, 248, 0.8)',
              }}
            />

            <div className="text-slate-400 font-mono text-sm tracking-widest mb-3 uppercase">
              Human Input String
            </div>
            <div className="text-6xl font-extrabold text-white tracking-wide font-mono mb-6">
              "Artificial"
            </div>

            <div className="w-12 h-12 rounded-full bg-cyan-500/20 text-cyan-400 flex items-center justify-center text-2xl font-bold my-2">
              ↓
            </div>

            <div className="text-slate-400 font-mono text-sm tracking-widest mt-2 mb-2 uppercase">
              Machine Numerical Token
            </div>
            <div className="text-5xl font-mono font-black text-cyan-300 bg-cyan-950/40 px-6 py-2 rounded-xl border border-cyan-500/40">
              ID #4281
            </div>
          </div>
        </BentoCard>

        {/* Lower Card: Vector Blocks & Token Counter */}
        <BentoCard className="flex-1 flex flex-col justify-between">
          <div className="flex justify-between items-center mb-4">
            <BentoBadge label="Embedding Matrix" color="#10B981" bg="rgba(16, 185, 129, 0.15)" />
            <span className="text-lg font-mono text-emerald-400 font-semibold">1 Word = 1 Unit</span>
          </div>

          <div className="flex-1 flex flex-col justify-center items-center">
            <div className="flex gap-4 items-center justify-center mb-6">
              <div
                className="w-48 h-28 rounded-2xl bg-emerald-500/20 border-2 border-emerald-400 flex flex-col items-center justify-center shadow-lg shadow-emerald-500/20"
                style={{
                  transform: `scale(${interpolate(lockProgress, [0, 1], [0.95, 1.05])})`,
                }}
              >
                <span className="text-xs font-mono text-emerald-300 uppercase tracking-widest">
                  Single Token
                </span>
                <span className="text-4xl font-mono font-black text-white mt-1">[4281]</span>
              </div>
            </div>

            <div className="text-2xl text-slate-200 font-medium text-center max-w-lg mb-4">
              AI models read numbers, not raw human text
            </div>

            <div className="flex gap-3 text-sm font-mono text-slate-400">
              <span className="px-4 py-1.5 rounded-lg bg-slate-900 border border-slate-700">
                Token Count: 1
              </span>
              <span className="px-4 py-1.5 rounded-lg bg-slate-900 border border-slate-700">
                Context Load: 1x
              </span>
            </div>
          </div>
        </BentoCard>
      </div>
    </SceneStage>
  );
};
