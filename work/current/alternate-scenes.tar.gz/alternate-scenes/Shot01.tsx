import React from 'react';
import {interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {SceneStage} from '../../shared/SceneStage';
import {BentoBadge, BentoCard} from './SceneBento';

export const Shot01: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();

  // Entrance spring
  const enterProgress = spring({frame, fps, config: {damping: 14, stiffness: 100}});
  const cardScale = interpolate(enterProgress, [0, 1], [0.92, 1]);
  const cardOpacity = interpolate(enterProgress, [0, 1], [0, 1]);

  // Event e01-resolve triggers at frame 109
  const spikeProgress = spring({
    frame: frame - 109,
    fps,
    config: {damping: 12, stiffness: 120},
  });
  const multiplierScale = interpolate(spikeProgress, [0, 1], [1, 1.15]);
  const multiplierColor = frame >= 109 ? '#EF4444' : '#F59E0B';

  return (
    <SceneStage>
      <div
        className="w-full h-full flex flex-col justify-between py-6 px-4"
        style={{
          opacity: cardOpacity,
          transform: `scale(${cardScale})`,
        }}
      >
        {/* Top Hero: Side-by-Side Prompt Sheet Comparison */}
        <BentoCard className="flex-1 mb-6 flex flex-col justify-between">
          <div className="flex justify-between items-center mb-6">
            <BentoBadge label="Side-by-Side Comparison" color="#38BDF8" />
            <span className="text-xl font-mono text-slate-400">LLM Cost Model</span>
          </div>

          <div className="grid grid-cols-2 gap-6 flex-1 items-stretch">
            {/* English Prompt Sheet */}
            <div
              className="rounded-2xl p-6 flex flex-col justify-between"
              style={{
                backgroundColor: 'rgba(15, 23, 42, 0.75)',
                border: '1.5px solid rgba(56, 189, 248, 0.4)',
              }}
            >
              <div>
                <span className="inline-block px-3 py-1 rounded-md text-sm font-bold bg-sky-500/20 text-sky-400 mb-4">
                  English Prompt
                </span>
                <p className="text-2xl font-mono text-slate-300 leading-relaxed">
                  "Explain quantum physics in simple terms"
                </p>
              </div>
              <div className="pt-4 border-t border-slate-700/50 flex justify-between items-end">
                <div>
                  <div className="text-sm font-mono text-slate-400">Tokens</div>
                  <div className="text-4xl font-extrabold text-emerald-400 font-mono">128</div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-mono text-slate-400">Rate</div>
                  <div className="text-2xl font-bold text-slate-200">1x Base</div>
                </div>
              </div>
            </div>

            {/* Bangla Prompt Sheet */}
            <div
              className="rounded-2xl p-6 flex flex-col justify-between"
              style={{
                backgroundColor: 'rgba(15, 23, 42, 0.75)',
                border: frame >= 109 ? '2px solid rgba(239, 68, 68, 0.8)' : '1.5px solid rgba(245, 158, 11, 0.4)',
                boxShadow: frame >= 109 ? '0 0 30px rgba(239, 68, 68, 0.25)' : 'none',
              }}
            >
              <div>
                <span
                  className="inline-block px-3 py-1 rounded-md text-sm font-bold mb-4"
                  style={{
                    backgroundColor: frame >= 109 ? 'rgba(239, 68, 68, 0.2)' : 'rgba(245, 158, 11, 0.2)',
                    color: multiplierColor,
                  }}
                >
                  বাংলা প্রম্পট
                </span>
                <p className="text-2xl font-sans text-slate-200 leading-relaxed font-medium">
                  "কোয়ান্টাম ফিজিক্স সহজ ভাষায় ব্যাখ্যা করুন"
                </p>
              </div>
              <div className="pt-4 border-t border-slate-700/50 flex justify-between items-end">
                <div>
                  <div className="text-sm font-mono text-slate-400">Tokens</div>
                  <div
                    className="text-4xl font-extrabold font-mono"
                    style={{color: multiplierColor}}
                  >
                    384
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-mono text-slate-400">Rate</div>
                  <div
                    className="text-2xl font-bold"
                    style={{color: multiplierColor}}
                  >
                    3x Cost
                  </div>
                </div>
              </div>
            </div>
          </div>
        </BentoCard>

        {/* Lower Telemetry Card: Big Multiplier Gauge */}
        <BentoCard
          className="flex-1 flex flex-col justify-center items-center text-center"
          glowColor={frame >= 109 ? 'rgba(239, 68, 68, 0.3)' : 'rgba(56, 189, 248, 0.2)'}
        >
          <div className="text-slate-400 text-lg uppercase tracking-widest font-mono mb-2">
            Usage Disparity Meter
          </div>

          <div
            className="my-4 font-mono font-black"
            style={{
              fontSize: '110px',
              lineHeight: '1',
              color: multiplierColor,
              transform: `scale(${multiplierScale})`,
              textShadow: frame >= 109 ? '0 0 40px rgba(239, 68, 68, 0.6)' : 'none',
            }}
          >
            3X COST
          </div>

          <p className="text-2xl text-slate-300 max-w-xl font-medium mt-2">
            Same concept. More token slices. Higher bill.
          </p>

          <div className="mt-6 flex gap-4">
            <span className="px-5 py-2 rounded-full text-base font-semibold bg-red-500/15 text-red-400 border border-red-500/30">
              Illustrative Comparison
            </span>
            <span className="px-5 py-2 rounded-full text-base font-semibold bg-slate-800 text-slate-300 border border-slate-700">
              Model Dependent
            </span>
          </div>
        </BentoCard>
      </div>
    </SceneStage>
  );
};
