import React from 'react';
import {interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {SceneStage} from '../../shared/SceneStage';
import {BentoBadge, BentoCard} from './SceneBento';

export const Shot09: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();

  const enterProgress = spring({frame, fps, config: {damping: 14, stiffness: 100}});
  const scale = interpolate(enterProgress, [0, 1], [0.94, 1]);

  const pulse = interpolate(Math.sin((frame / fps) * Math.PI * 2), [-1, 1], [0.97, 1.03]);

  return (
    <SceneStage>
      <div
        className="w-full h-full flex flex-col justify-between py-6 px-4"
        style={{transform: `scale(${scale})`}}
      >
        {/* Top Hero: Key Technical Takeaways */}
        <BentoCard className="flex-1 mb-6 flex flex-col justify-between">
          <div className="flex justify-between items-center mb-4">
            <BentoBadge label="Core Summary" color="#38BDF8" />
            <span className="text-lg font-mono text-slate-400">Technical Takeaways</span>
          </div>

          <div className="flex-1 flex flex-col justify-around py-2">
            <div className="flex items-center gap-5 p-4 rounded-2xl bg-slate-900/60 border border-slate-700/60">
              <div className="w-12 h-12 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center font-mono font-bold text-2xl">
                01
              </div>
              <div>
                <div className="text-2xl font-bold text-white">Models Read Tokens, Not Words</div>
                <div className="text-base text-slate-400">Cost follows token units, not character count.</div>
              </div>
            </div>

            <div className="flex items-center gap-5 p-4 rounded-2xl bg-slate-900/60 border border-slate-700/60">
              <div className="w-12 h-12 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-mono font-bold text-2xl">
                02
              </div>
              <div>
                <div className="text-2xl font-bold text-white">Unicode Splitting Adds Overhead</div>
                <div className="text-base text-slate-400">BPE splits complex conjuncts into raw UTF-8 bytes.</div>
              </div>
            </div>

            <div className="flex items-center gap-5 p-4 rounded-2xl bg-slate-900/60 border border-slate-700/60">
              <div className="w-12 h-12 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-mono font-bold text-2xl">
                03
              </div>
              <div>
                <div className="text-2xl font-bold text-white">Use Hybrid Prompt Workflows</div>
                <div className="text-base text-slate-400">Prompt in English, generate in Bangla for max efficiency.</div>
              </div>
            </div>
          </div>
        </BentoCard>

        {/* Lower Card: Call to Action */}
        <BentoCard
          className="flex-1 flex flex-col justify-center items-center text-center"
          glowColor="rgba(56, 189, 248, 0.3)"
        >
          <div className="text-slate-400 font-mono text-lg uppercase tracking-widest mb-3">
            Tech Insights & Architecture
          </div>

          <div
            className="px-10 py-5 rounded-3xl bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-black text-4xl tracking-wider shadow-2xl shadow-cyan-500/40 my-3"
            style={{transform: `scale(${pulse})`}}
          >
            FOLLOW FOR MORE
          </div>

          <p className="text-2xl text-slate-300 font-medium mt-4">
            ট্যাকনিক্যাল দুনিয়ার এমন ভেতরের খবর জানতে ফলো করে রাখুন!
          </p>
        </BentoCard>
      </div>
    </SceneStage>
  );
};
