import React from 'react';
import {interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {SceneStage} from '../../shared/SceneStage';
import {BentoBadge, BentoCard} from './SceneBento';

export const Shot05: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();

  const enterProgress = spring({frame, fps, config: {damping: 14, stiffness: 100}});
  const scale = interpolate(enterProgress, [0, 1], [0.94, 1]);

  // Slicing trigger at frame 118
  const sliceProgress = spring({
    frame: frame - 118,
    fps,
    config: {damping: 12, stiffness: 120},
  });

  const byteSpread = interpolate(sliceProgress, [0, 1], [0, 20]);

  return (
    <SceneStage>
      <div
        className="w-full h-full flex flex-col justify-between py-6 px-4"
        style={{transform: `scale(${scale})`}}
      >
        {/* Top Hero: Byte-Pair Laser Slicing Machine */}
        <BentoCard className="flex-1 mb-6 flex flex-col justify-between">
          <div className="flex justify-between items-center mb-4">
            <BentoBadge label="BPE Byte Slicer" color="#EF4444" bg="rgba(239, 68, 68, 0.15)" />
            <span className="text-lg font-mono text-amber-400 font-semibold">Subword Fragmentation</span>
          </div>

          <div className="flex-1 flex flex-col justify-center items-center relative overflow-hidden">
            {/* The Original Bengali Word */}
            <div className="text-slate-400 font-mono text-sm tracking-widest uppercase mb-2">
              Input Bangla Word
            </div>
            <div className="text-7xl font-sans font-bold text-white tracking-wide mb-6">
              "প্রকৌশল"
            </div>

            {/* Laser slicing beam */}
            {frame >= 118 && (
              <div className="w-full h-1 bg-red-500 shadow-[0_0_20px_4px_rgba(239,68,68,0.9)] my-2" />
            )}

            {/* Sliced UTF-8 Bytes */}
            <div className="flex gap-3 mt-4 flex-wrap justify-center">
              {['[E0]', '[A6]', '[AA]', '[E0]', '[A7]'].map((byte, idx) => (
                <div
                  key={idx}
                  className="px-4 py-2 rounded-xl bg-red-950/60 border border-red-500/50 text-red-300 font-mono text-xl font-bold"
                  style={{
                    transform: `translateY(${idx % 2 === 0 ? byteSpread : -byteSpread}px)`,
                  }}
                >
                  {byte}
                </div>
              ))}
            </div>
          </div>

          <div className="pt-4 border-t border-slate-700/50 text-center text-slate-400 font-mono text-base">
            BPE does not contain whole Bangla words in vocabulary → Falls back to raw bytes
          </div>
        </BentoCard>

        {/* Lower Card: 1 Word to 4-5 Tokens Multiplier */}
        <BentoCard className="flex-1 flex flex-col justify-between">
          <div className="flex justify-between items-center mb-4">
            <BentoBadge label="Fragmentation Yield" color="#F59E0B" bg="rgba(245, 158, 11, 0.15)" />
            <span className="text-lg font-mono text-red-400 font-semibold">High Multiplier</span>
          </div>

          <div className="flex-1 flex flex-col justify-center items-center text-center">
            <div className="text-slate-400 font-mono text-lg uppercase tracking-wider mb-2">
              Resulting Token Count
            </div>
            <div className="text-8xl font-mono font-black text-amber-400 tracking-tight my-2">
              4 to 5 PIECES
            </div>
            <p className="text-2xl text-slate-300 max-w-xl font-medium mt-2">
              One single Bangla word produces 4 to 5 separate token charges.
            </p>
          </div>

          <div className="flex justify-around pt-4 border-t border-slate-700/50 text-center font-mono text-base text-slate-400">
            <span>[UTF-8 ENCODING]</span>
            <span>[SUBWORD RECURSION]</span>
            <span>[MODEL DEPENDENT]</span>
          </div>
        </BentoCard>
      </div>
    </SceneStage>
  );
};
