import React from 'react';
import {interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {SceneStage} from '../../shared/SceneStage';
import {BentoBadge, BentoCard} from './SceneBento';

export const Shot08: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();

  const enterProgress = spring({frame, fps, config: {damping: 14, stiffness: 100}});
  const scale = interpolate(enterProgress, [0, 1], [0.94, 1]);

  // Success stamp at frame 100
  const stampProgress = spring({
    frame: frame - 100,
    fps,
    config: {damping: 10, stiffness: 140},
  });

  return (
    <SceneStage>
      <div
        className="w-full h-full flex flex-col justify-between py-6 px-4"
        style={{transform: `scale(${scale})`}}
      >
        {/* Top Hero: The Optimized Hybrid Prompt Pipeline */}
        <BentoCard className="flex-1 mb-6 flex flex-col justify-between" glowColor="rgba(16, 185, 129, 0.25)">
          <div className="flex justify-between items-center mb-4">
            <BentoBadge label="Pro-Tip Strategy" color="#10B981" bg="rgba(16, 185, 129, 0.15)" />
            <span className="text-lg font-mono text-emerald-400 font-semibold">Smart Prompting</span>
          </div>

          <div className="flex-1 flex flex-col justify-center items-center">
            <div className="w-full max-w-xl flex items-center justify-between gap-4 my-2">
              {/* Step 1: Input English */}
              <div className="flex-1 p-5 rounded-2xl bg-slate-900 border-2 border-cyan-500/50 flex flex-col items-center text-center">
                <span className="text-xs font-mono text-cyan-400 uppercase tracking-widest mb-1">Step 1: Input</span>
                <span className="text-xl font-bold text-white mb-1">Prompt in English</span>
                <span className="text-xs font-mono text-slate-400">Minimal Token Footprint</span>
              </div>

              {/* Arrow */}
              <div className="text-3xl font-bold text-emerald-400">→</div>

              {/* Step 2: Output Bangla */}
              <div className="flex-1 p-5 rounded-2xl bg-slate-900 border-2 border-emerald-500/50 flex flex-col items-center text-center">
                <span className="text-xs font-mono text-emerald-400 uppercase tracking-widest mb-1">Step 2: Output</span>
                <span className="text-xl font-bold text-white mb-1">Output in Bangla</span>
                <span className="text-xs font-mono text-slate-400">Natural Fluent Response</span>
              </div>
            </div>

            <p className="text-2xl text-slate-200 font-medium text-center mt-6">
              Give large code or logic prompts in English, request the output in Bengali
            </p>
          </div>
        </BentoCard>

        {/* Lower Card: Cost & Efficiency Yield */}
        <BentoCard className="flex-1 flex flex-col justify-between">
          <div className="flex justify-between items-center mb-4">
            <BentoBadge label="Optimization Yield" color="#38BDF8" />
            <span className="text-lg font-mono text-slate-400">Efficiency Metric</span>
          </div>

          <div className="flex-1 flex flex-col justify-center items-center text-center">
            <div className="text-slate-400 font-mono text-lg uppercase tracking-wider mb-2">
              Context & Token Efficiency
            </div>
            <div
              className="text-8xl font-mono font-black text-emerald-400 tracking-tight my-2"
              style={{
                transform: `scale(${interpolate(stampProgress, [0, 1], [0.9, 1.05])})`,
              }}
            >
              60% - 70%
            </div>
            <p className="text-2xl text-emerald-300 font-semibold mt-1">
              TOKEN LOAD REDUCTION
            </p>
          </div>

          <div className="pt-4 border-t border-slate-700/50 text-center font-mono text-base text-slate-400">
            Best practice for complex software tasks, long documents, and automated pipelines.
          </div>
        </BentoCard>
      </div>
    </SceneStage>
  );
};
