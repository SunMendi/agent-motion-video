import React from 'react';
import {interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {SceneStage} from '../../shared/SceneStage';
import {BentoBadge, BentoCard} from './SceneBento';

export const Shot02: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();

  // Entrance
  const enterProgress = spring({frame, fps, config: {damping: 14, stiffness: 100}});
  const scale = interpolate(enterProgress, [0, 1], [0.94, 1]);

  // Balance drain animation
  const balance = interpolate(frame, [0, 200], [50.0, 32.4], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  }).toFixed(2);

  // Event e02-resolve at frame 127
  const revealProgress = spring({
    frame: frame - 127,
    fps,
    config: {damping: 12, stiffness: 110},
  });

  return (
    <SceneStage>
      <div
        className="w-full h-full flex flex-col justify-between py-6 px-4"
        style={{transform: `scale(${scale})`}}
      >
        {/* Top Hero: Wallet Credit Drain */}
        <BentoCard className="flex-1 mb-6 flex flex-col justify-between">
          <div className="flex justify-between items-center">
            <BentoBadge label="Credit Depletion" color="#EF4444" bg="rgba(239, 68, 68, 0.15)" />
            <span className="text-xl font-mono text-red-400 font-semibold animate-pulse">
              ● Live Drain
            </span>
          </div>

          <div className="flex flex-col items-center justify-center my-6">
            <div className="text-slate-400 font-mono text-lg uppercase tracking-wider mb-2">
              API Wallet Balance
            </div>
            <div className="text-8xl font-black font-mono text-red-400 tracking-tight">
              ${balance}
            </div>
            <div className="mt-4 flex items-center gap-3 px-4 py-2 rounded-xl bg-red-950/40 border border-red-500/30 text-red-300 font-mono text-base">
              <span>⚠️ Accelerated Consumption</span>
            </div>
          </div>

          <div className="w-full bg-slate-800 rounded-full h-3 overflow-hidden">
            <div
              className="bg-red-500 h-full rounded-full"
              style={{
                width: `${interpolate(frame, [0, 200], [100, 60], {
                  extrapolateLeft: 'clamp',
                  extrapolateRight: 'clamp',
                })}%`,
              }}
            />
          </div>
        </BentoCard>

        {/* Lower Card: The Investigation (Bias vs Math) */}
        <BentoCard className="flex-1 flex flex-col justify-between">
          <div className="flex justify-between items-center mb-4">
            <BentoBadge label="Root Cause Analysis" color="#38BDF8" />
            <span className="text-lg font-mono text-slate-400">Encoding Logic</span>
          </div>

          <div className="grid grid-cols-2 gap-6 flex-1 items-center">
            {/* Left: Anti-Theory (Bias) */}
            <div className="rounded-2xl p-6 bg-slate-900/60 border border-slate-700/60 flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full bg-red-500/20 text-red-400 flex items-center justify-center text-3xl font-bold mb-3">
                ✕
              </div>
              <div className="text-2xl font-bold text-slate-200 mb-1">Company Bias?</div>
              <div className="text-base text-slate-400 font-medium">
                No policy bias or regional discrimination
              </div>
            </div>

            {/* Right: Actual Cause (Math & Encoding) */}
            <div
              className="rounded-2xl p-6 flex flex-col items-center text-center"
              style={{
                backgroundColor: 'rgba(16, 185, 129, 0.12)',
                border: frame >= 127 ? '2px solid rgba(16, 185, 129, 0.8)' : '1.5px solid rgba(16, 185, 129, 0.3)',
                boxShadow: frame >= 127 ? '0 0 30px rgba(16, 185, 129, 0.25)' : 'none',
                transform: `scale(${interpolate(revealProgress, [0, 1], [0.95, 1.03])})`,
              }}
            >
              <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-3xl font-bold mb-3">
                ✓
              </div>
              <div className="text-2xl font-bold text-emerald-300 mb-1">Pure Mathematics</div>
              <div className="text-base text-slate-300 font-medium">
                Byte-Pair Encoding (BPE) & Unicode Byte Matrix
              </div>
            </div>
          </div>

          {/* Micro badges */}
          <div className="flex justify-around pt-4 border-t border-slate-700/50 mt-4 text-center font-mono text-sm text-slate-400">
            <span>[BPE ALGORITHM]</span>
            <span>[UTF-8 BYTES]</span>
            <span>[VOCABULARY LOOKUP]</span>
          </div>
        </BentoCard>
      </div>
    </SceneStage>
  );
};
