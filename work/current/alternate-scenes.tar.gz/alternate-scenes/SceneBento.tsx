import React from 'react';

export const BentoCard: React.FC<{
  children: React.ReactNode;
  className?: string;
  style?: React.CSSProperties;
  glowColor?: string;
}> = ({children, className = '', style = {}, glowColor = 'rgba(56, 189, 248, 0.15)'}) => (
  <div
    className={`relative rounded-3xl p-8 border border-white/10 backdrop-blur-md overflow-hidden ${className}`}
    style={{
      backgroundColor: '#1E293B',
      boxShadow: `0 20px 40px -15px rgba(0, 0, 0, 0.5), 0 0 25px 0 ${glowColor}`,
      ...style,
    }}
  >
    {children}
  </div>
);

export const BentoBadge: React.FC<{
  label: string;
  color?: string;
  bg?: string;
  icon?: React.ReactNode;
}> = ({label, color = '#38BDF8', bg = 'rgba(56, 189, 248, 0.15)', icon}) => (
  <div
    className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-lg font-bold tracking-wider uppercase"
    style={{color, backgroundColor: bg, border: `1px solid ${color}40`}}
  >
    {icon}
    <span>{label}</span>
  </div>
);
