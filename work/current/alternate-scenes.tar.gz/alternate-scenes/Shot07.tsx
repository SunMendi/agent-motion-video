import React from 'react';
import {interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {SceneStage} from '../../shared/SceneStage';
import {BentoBadge, BentoCard} from './SceneBento';

export const Shot07: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();

  const enterProgress = spring({frame, fps, config: {damping: 14, stiffness: 100}});
  const scale = interpolate(enterProgress, [0, 1], [0.94, 1]);

  // Buffer fill progress
  const fillProgress = interpolate(frame, [0, 150], [20, 88], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  // e07-resolve at frame 94
  const spikeProgress = spring({
    frame: frame - 94,
    fps,
    config: {damping: 12, stiffness: 120},
  });

  return (
    <SceneStage>
      <div
        className="w-full h-full flex flex-col justify-between py-6 px-4"
        style={{transform: `scale(${scale})`}}
      >
        {/* Top Hero: Context Window Memory Overflow */}
        <BentoCard className="flex-1 mb-6 flex flex-col justify-between" glowColor="rgba(239, 68, 68, 0.25)">
          <div className="flex justify-between items-center mb-4">
            <BentoBadge label="Context Exhaustion" color="#EF4444" bg="rgba(239, 68, 68, 0.15)" />
            <span className="text-lg font-mono text-red-400 font-semibold animate-pulse">
              ● Buffer Critical
            </span>
          </div>

          <div className="flex-1 flex flex-col justify-center items-center">
            <div className="text-slate-400 font-mono text-sm tracking-widest uppercase mb-2">
              Model Attention Window (128k Tokens)
            </div>

            {/* Gauge Display */}
            <div className="text-8xl font-black font-mono text-red-400 tracking-tight my-2">
              {Math.round(fillProgress)}% FULL
            </div>

            <div className="w-full bg-slate-800 rounded-full h-5 overflow-hidden my-4 border border-slate-700">
              <div
                className="bg-gradient-to-r from-amber-500 to-red-500 h-full rounded-full"
                style={{width: `${fillProgress}%`}}
              />
            </div>

            <p className="text-xl text-slate-300 font-medium text-center">
              Higher token density consumes AI memory 3x faster
            </p>
          </div>
        </BentoCard>

        {/* Lower Card: 3X API Invoice Multiplier */}
        <BentoCard className="flex-1 flex flex-col justify-between">
          <div className="flex justify-between items-center mb-4">
            <BentoBadge label="Financial Impact" color="#F59E0B" bg="rgba(245, 158, 11, 0.15)" />
            <span className="text-lg font-mono text-slate-400">Monthly Usage</span>
          </div>

          <div className="grid grid-cols-2 gap-6 flex-1 items-center">
            <div className="rounded-2xl p-6 bg-slate-900/60 border border-slate-700 flex flex-col justify-center items-center">
              <div className="text-sm font-mono text-slate-400 uppercase mb-2">Standard Rate</div>
              <div className="text-5xl font-mono font-bold text-slate-200">$10.00</div>
              <div className="text-xs font-mono text-slate-500 mt-2">1x Base Billing</div>
            </div>

            <div
              className="rounded-2xl p-6 bg-red-950/40 border-2 border-red-500/60 flex flex-col justify-center items-center shadow-lg shadow-red-500/20"
              style={{
                transform: `scale(${interpolate(spikeProgress, [0, 1], [1, 1.05])})`,
              }}
            >
              <div className="text-sm font-mono text-red-400 uppercase font-bold mb-2">Multiplied Rate</div>
              <div className="text-5xl font-mono font-black text-red-400">$30.00</div>
              <div className="text-xs font-mono text-red-300 mt-2">3x Token Load</div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-700/50 text-center font-mono text-sm text-slate-400">
            More input tokens = Shorter conversation memory + Higher monthly API bills
          </div>
        </BentoCard>
      </div>
    </SceneStage>
  );
};
